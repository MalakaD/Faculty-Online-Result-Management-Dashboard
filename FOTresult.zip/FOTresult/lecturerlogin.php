<?php
session_start();
error_reporting(0);
include('config.php');
if($_SESSION['alogin']!=''){
$_SESSION['alogin']='';
}
if(isset($_POST['login']))
{
$uname=$_POST['email'];
$password=($_POST['password']);
$sql ="SELECT Password FROM lecturer WHERE LecEmail=:uname and Password=:password and LoginAcces='Yes' ";
$query= $dbh -> prepare($sql);
$query-> bindParam(':uname', $uname, PDO::PARAM_STR);
$query-> bindParam(':password', $password, PDO::PARAM_STR);
$query-> execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);

if($query->rowCount() > 0)

{

$_SESSION['alogin']=$_POST['email'];
echo "<script type='text/javascript'> document.location = 'LecturerPanel/index.php'; </script>";
} else{
    
    echo "<script>alert('Invalid Details');</script>";

}

}

?>











<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>FOT Result Dashboard</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/fonts/line-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
</head>

<body>
    <div class="login-dark" style="background-image: url(&quot;assets/img/How-to-Become-a-University-Lecturer.jpg&quot;);">
        <div style="height: 1003px;background-color: rgba(6,42,228,0.39);">
            <h1 class="text-center" style="padding-top: 85px;color: rgb(236,240,244);background-color: rgba(18,0,129,0.48);"><strong>Lecturer Login</strong></h1>
            <div class="row" style="margin-top: 200px;">
                <div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center text-sm-center text-md-center text-lg-center text-xl-center"><a href="index.php"><i class="fa fa-home" style="color: #ffffff;font-size: 87px;"></i><p style="color: rgb(255,255,255);"><strong>Home</strong></p></a></div>
                <div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center text-sm-center text-md-center text-lg-center text-xl-center">
                    <form method="post" style="opacity: 1;background-color: rgba(5,4,75,0.36);width: 319px;padding: 30px;padding-right: 34px;">
                        <h2 class="sr-only">Login Form</h2>
                        <div class="illustration" style="opacity: 1;padding: 10px;"><i class="icon ion-ios-locked-outline" style="color: rgb(255,255,255);"></i></div>
                        <div class="form-group"><input class="form-control" type="email" name="email" placeholder="University E-mail" style="opacity: 1;color: rgb(255,255,255);filter: brightness(200%);"></div>
                        <div class="form-group"><input class="form-control" type="password" name="password" placeholder="Password" style="filter: brightness(200%);"></div>
                        <div class="form-group"><button class="btn btn-primary btn-block" name="login" type="submit" style="color: rgb(255,255,255);">Log In</button></div><a class="forgot" href="#" style="color: rgb(255,255,255);">Forgot your email or password?</a></form>
                </div>
                <div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center text-sm-center text-md-center text-lg-center text-xl-center"><a href="lectureREG.php"><i class="fa fa-address-card-o" style="color: rgb(255,255,255);font-size: 72px;"></i><p style="color: rgb(255,255,255);"><strong>Register</strong></p></a></div>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>