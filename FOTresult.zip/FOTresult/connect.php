<?php


$studentname=$_POST['Name'];
$StREGnumber=$_POST['StRegID']; 
$studentemail=$_POST['email']; 
$StPassword=$_POST['password']; 
$confirmPassword=$_POST['password-repeat']; 
$StGender=$_POST['Gender']; 
$StDepartment=$_POST['Department']; 
$StYear=$_POST['Year']; 
$StRegYear=$_POST['RegYear']; 
$Acces="NO";

	// Database connection
	$conn = new mysqli('localhost','root','','fotresult');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
		
	} else {
		$stmt = $conn->prepare("insert into student(StName,RegNumber,StEmail, Password, Gender, Department, Year, RegYear,LoginAcces) values(?, ?, ?, ?, ?, ?, ?, ?,?)");
		$stmt->bind_param("sssssssss", $studentname,$StREGnumber, $studentemail, $StPassword, $StGender, $StDepartment,$StYear,$StRegYear,$Acces);
		$execval = $stmt->execute();
		echo $execval;
		echo "<script>alert('Registration Succesfully');document.location = 'Studentlogin.php';</script>";
		
		$stmt->close();
		$conn->close();
		
	}
	
?>