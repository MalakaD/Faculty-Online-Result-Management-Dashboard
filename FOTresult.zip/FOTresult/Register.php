<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>FOT Result Dashboard</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/fonts/line-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
</head>

<body>
    <div class="register-photo" style="background-image: url(&quot;assets/img/IMG_2036.JPG&quot;);background-size: cover;height: 1013px;margin-top: -29px;">
        <h1 style="color: rgb(255,255,255);margin-left: 296px;margin-top: 0px;height: 102px;padding-left: 289px;"><strong>Registration</strong></h1>
        <div style="background-color: rgba(38,7,5,0.33);margin-top: -34px;">
            <div class="row">
                <div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center text-sm-center text-md-center text-lg-center text-xl-center"><a href="index.php"><i class="fa fa-home" style="color: rgb(255,255,255);font-size: 106px;margin-top: 193px;"></i><p style="color: rgb(255,255,255);"><strong>Home</strong></p></a></div>
                <div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center text-sm-center text-md-center text-lg-center text-xl-center">
                    <div class="text-center text-sm-center text-md-center text-lg-center text-xl-center form-container" style="width: 558px;margin-left: -42px;height: 589px;background-color: rgba(37,70,242,0.53);"><a href="lectureREG.php" style="margin-top: 0px;"><i class="fas fa-user-tie" style="color: rgb(255,255,255);font-size: 106px;margin-top: 106px;"></i><p style="color: rgb(255,255,255);"><strong>Lecturer Registration</strong></p></a>
                        <a
                            href="StudentREG.php" style="margin-top: 0px;"><i class="fas fa-user-graduate" style="color: rgb(255,255,255);font-size: 106px;margin-top: 7px;"></i>
                            <p style="color: rgb(255,255,255);"><strong>Student Registration</strong></p>
                            </a>
                    </div>
                </div>
                <div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center text-sm-center text-md-center text-lg-center text-xl-center"><a href="#"><i class="fa fa-paste" style="color: rgb(250,252,255);font-size: 80px;margin-top: 193px;"></i><p style="color: rgb(255,255,255);"><strong>Guidline</strong></p></a></div>
            </div>
        </div>
    </div>
    <div style="background-color: rgba(72,89,2,0.48);height: 279px;margin-top: -270px;"></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>