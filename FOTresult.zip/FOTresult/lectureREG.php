<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>FOT Result Dashboard</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/fonts/line-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
	<script>
function validateForm() {
 



  var x = document.forms["myForm"]["Name"].value;
  var y = document.forms["myForm"]["LecId"].value;
  var z = document.forms["myForm"]["email"].value;
  var a = document.forms["myForm"]["password"].value;
  var b = document.forms["myForm"]["password-repeat"].value;
  var c = document.forms["myForm"]["gender"].value;
  var d = document.forms["myForm"]["Department"].value;

  
  if (x == "") {
    alert("email must be filled out");
    return false;
  }
  if (y == "") {
    alert("email must be filled out");
    return false;
  }
  if (z == "") {
    alert("email must be filled out");
    return false;
  }
  if (a == "") {
    alert("email must be filled out");
    return false;
  }
  if (b !== a) {
    alert("email must be filled out");
    return false;
	
  }
  if (c == "") {
    alert("email must be filled out");
    return false;
  }
  if (b == "") {
    alert("email must be filled out");
    return false;
  }
  if (d == "") {
    alert("email must be filled out");
    return false;
  }
 
}



</script>
</head>

<body>
    <div class="register-photo" style="background-image: url(&quot;assets/img/IMG_2036.JPG&quot;);background-size: cover;height: 1013px;margin-top: -29px;">
        <h1 style="color: rgb(255,255,255);margin-left: 436px;margin-top: 23px;height: 102px;padding: 0px;padding-left: 52px;padding-bottom: 0px;margin-bottom: 0px;"><strong>Lecturer Registration</strong></h1>
        <div style="background-color: rgba(38,7,5,0.33);margin-top: -34px;">
            <div class="row">
                <div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center text-sm-center text-md-center text-lg-center text-xl-center"><a href="index.php"><i class="fa fa-home" style="color: rgb(255,255,255);font-size: 106px;margin-top: 193px;"></i><p style="color: rgb(255,255,255);"><strong>Home</strong></p></a></div>
                <div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center text-sm-center text-md-center text-lg-center text-xl-center">
                    <div class="text-center text-sm-center text-md-center text-lg-center text-xl-center form-container" style="width: 558px;margin-left: -42px;">
                        <form action="lecregconnect.php" name="myForm" onsubmit="return validateForm()" class="text-center text-sm-center text-md-center text-lg-center text-xl-center" method="post" style="background-color: rgba(19,36,126,0.54);padding: 104px;padding-top: 4px;height: 588px;padding-bottom: 37px;">
                            <h2 class="text-center" style="color: rgb(255,255,255);"><strong>Create</strong> an account.</h2>
                            <div class="form-group"><input class="form-control" type="email" name="email" placeholder="Enter your University E-mail" style="background-color: rgba(247,249,252,0);color: rgb(255,255,255);filter: brightness(200%);"></div>
                            <div class="form-group"><input class="form-control" type="text" name="Name" placeholder="Enter your Name with intial" style="background-color: rgba(247,249,252,0);color: rgb(255,255,255);filter: brightness(200%);"></div>
                            <div class="form-group"><input class="form-control" type="text" style="background-color: rgba(247,249,252,0);color: rgb(255,255,255);filter: brightness(200%);" placeholder="Enter Lecturer ID " name="LecId"></div>
                            <div class="form-group"><input class="form-control" type="password" name="password" placeholder="Password" style="background-color: rgba(247,249,252,0);color: rgb(255,255,255);filter: brightness(200%);"></div>
                            <div class="form-group"><input class="form-control" type="password" name="password-repeat" placeholder="Confirm Password " style="background-color: rgba(247,249,252,0);color: rgb(255,255,255);filter: brightness(200%);" required=""></div>
                            <p style="color: #2a72ff;filter: brightness(171%);margin-bottom: -2px;"><strong>Gender</strong></p><select class="form-control" name="gender" style="width: 353px;margin-left: 0px;background-color: rgba(18,105,234,0.56);color: rgb(255,255,255);"><optgroup label="Gender"><option value="Mail" selected="">Male</option><option value="Femail">Female</option></optgroup></select>
                            <p
                                style="color: #2a72ff;filter: brightness(171%);"><strong>Department</strong></p><select class="bg-primary form-control" name="Department" style="color: rgb(255,255,255);opacity: 0.56;margin-top: -16px;filter: brightness(100%);"><optgroup label="Department"><option value="ICT">Department of ICT</option><option value="ENT">Department of ENT</option><option value="BST">Department of BST</option><option value=" EET">Department of EET</option><option value="MTT">Department of MTT</option><option value="BPT">Department of BPT</option><option value="FDT">Department of FDT</option></optgroup></select>
                                <div
                                    class="form-group">
                                    <div class="form-check"><label class="form-check-label" style="color: rgb(87,245,255);margin: 58px;padding: 0px;margin-top: 15px;"><input class="form-check-input" type="checkbox">I agree to the license terms.</label></div>
                    </div>
                    <div class="form-group"><button class="btn btn-primary btn-block" type="submit" style="background-color: rgba(63,70,235,0.62);margin-top: -45px;"><strong>Sign Up&nbsp;</strong>As a Lecturer</button></div><a class="already" href="#" style="color: #2ff8bc;">You already have an account? Login here.</a></form>
                </div>
            </div>
            <div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center text-sm-center text-md-center text-lg-center text-xl-center"><a href="#"><i class="fa fa-paste" style="color: rgb(250,252,255);font-size: 80px;margin-top: 193px;"></i><p style="color: rgb(255,255,255);"><strong>Guidline</strong></p></a></div>
        </div>
    </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>