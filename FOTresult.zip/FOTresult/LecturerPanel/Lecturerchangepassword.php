

<?php
session_start();
error_reporting(0);
include('config.php');
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
    }
    else{
if(isset($_POST['submit']))
    {
$password=($_POST['password']);
$newpassword=($_POST['newpassword']);
$username=$_SESSION['alogin'];
    $sql ="SELECT Password FROM lecturer WHERE LecEmail=:username and Password=:password";
$query= $dbh -> prepare($sql);
$query-> bindParam(':username', $username, PDO::PARAM_STR);
$query-> bindParam(':password', $password, PDO::PARAM_STR);
$query-> execute();
$results = $query -> fetchAll(PDO::FETCH_OBJ);
if($query -> rowCount() > 0)
{
$con="UPDATE lecturer set Password=:newpassword where LecEmail=:username";
$chngpwd1 = $dbh->prepare($con);
$chngpwd1-> bindParam(':username', $username, PDO::PARAM_STR);
$chngpwd1-> bindParam(':newpassword', $newpassword, PDO::PARAM_STR);
$chngpwd1->execute();
$msg="Your Password succesfully changed";
}
else {
$error="Your current password is wrong";    
}
}}
?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>admindashboard</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
	
	<script>
	
function valid()
{
if(document.chngpwd.newpassword.value != document.chngpwd.confirmpassword.value)
{
alert("New Password and Confirm Password Field do not match  !!");
document.chngpwd.confirmpassword.focus();
return false;
}
return true;
alert("changed password");
}
</script>
	
	
</head>

<body>
    <div id="wrapper">
        <nav class="navbar navbar-dark bg-info align-items-start sidebar sidebar-dark accordion bg-gradient-primary p-0" style="background-color: rgb(45,121,164);height: 895px;">
            <div class="container-fluid d-flex flex-column p-0">
                <a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="#">
                    <div class="sidebar-brand-icon rotate-n-15"></div>
                    <div class="sidebar-brand-text mx-3"><img src="assets/img/150px-Rajarata_logo.png" style="font-size: 13px;width: 38px;margin-right: 12px;margin-left: -81px;margin-bottom: 17px;"><span>Lec</span></div>
                </a>
                <hr class="sidebar-divider my-0">
                <ul class="nav navbar-nav text-light" id="accordionSidebar">
                    <li class="nav-item" role="presentation"><a class="nav-link" href="index.php"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="AddReult.php"><i class="fas fa-list-ul"></i><span>Add results</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="openresult.php"><i class="fas fa-table"></i><span>Open all results</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="SubjectEnrolling.php"><i class="fas fa-file-alt"></i><span>Subject Enrolling</span></a></li>
                    <a class="nav-link active" href="Lecturerchangepassword.php"><i class="fas fa-key"></i>Change Password<span></span></a></li>
                </ul>
                <div class="text-center d-none d-md-inline"><button class="btn rounded-circle border-0" id="sidebarToggle" type="button"></button></div>
            </div>
        </nav>
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content" style="background-image: url(&quot;assets/img/IMG_2036.JPG&quot;);background-size: cover;">
                <div style="background-color: rgba(5,64,60,0.88);height: 61px;">
                    <h1 style="font-size: 28px;padding-top: 9px;color: rgb(255,255,255);">&nbsp;Change Password</h1>
                </div>
                <div style="background-color: rgba(22,10,69,0.62);height: 759px;">
                    <form method="post" onSubmit="return valid();" style="height: 527px;color: rgb(255,255,255);"><label style="margin-left: 260px;margin-top: 123px;padding-top: 2px;color: rgb(255,255,255);">Enter&nbsp;Current Password&nbsp; &nbsp; &nbsp;:&nbsp;</label><input class="form-control" name="password"  type="text" style="width: 326px;margin-left: 467px;margin-top: -36px;background-color: rgba(255,255,255,0);color: rgb(255,255,255);">
                        <label
                            style="margin-left: 260px;margin-top: 43px;padding-top: 2px;color: rgb(255,255,255);">Enter New password&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; :</label><input class="form-control" name="newpassword" type="text" style="width: 326px;margin-left: 468px;margin-top: -36px;background-color: rgba(255,255,255,0);color: rgb(255,255,255);">
                            <label
                                style="margin-left: 260px;margin-top: 43px;padding-top: 2px;color: rgb(255,255,255);">Confirm Password&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; :</label><input class="form-control" name="confirmpassword" type="text" style="width: 326px;margin-left: 468px;margin-top: -36px;background-color: rgba(255,255,255,0);color: rgb(255,255,255);">
                                <button
                                    class="btn btn-primary" name="submit" type="submit" style="background-color: rgba(22,213,178,0.91);margin-left: 468px;margin-top: 24px;width: 103px;">Change</button>
                    </form>
                </div>
            </div>
            <footer class="sticky-footer" style="background-color: #042529;">
                <div class="container my-auto">
                    <div class="text-center my-auto copyright"><span>Copyright © Rajarata university 2020</span></div>
                </div>
            </footer>
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/chart.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
    <script src="assets/js/script.min.js"></script>
</body>

</html>