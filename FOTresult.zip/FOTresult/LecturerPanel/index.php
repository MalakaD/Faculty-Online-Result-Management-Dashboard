<?php


include('config.php');


$sql ="SELECT COUNT(*) FROM student ";
$sqlone ="SELECT COUNT(*) FROM subject ";
$query= $dbh -> query($sql);
$queryone= $dbh -> query($sqlone);
$count = $query->fetchColumn();
$countone = $queryone->fetchColumn();

/*$LecID=$_POST["LecId"];
$_SESSION['LecID']=$LecID;


$sqlenrolled ="SELECT COUNT(*) FROM subjectenrolllecturer where subjectenrolllecturer.LecId='No' ";
$queryenroll= $dbh -> query($sqlenrolled);
$queryenroll->bindParam(':LecID',$LecID,PDO::PARAM_STR);

$countenroll = $queryenroll->fetchColumn();
*/




?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Dashboard - Brand</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
</head>

<body id="page-top" style="height: 891px;">
    <div id="wrapper" style="height: 896px;">
        <nav class="navbar navbar-dark bg-info align-items-start sidebar sidebar-dark accordion bg-gradient-primary p-0" style="background-color: rgb(45,121,164);height: 895px;">
            <div class="container-fluid d-flex flex-column p-0">
                <a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="#">
                    <div class="sidebar-brand-icon rotate-n-15"></div>
                    <div class="sidebar-brand-text mx-3"><img src="assets/img/150px-Rajarata_logo.png" style="font-size: 13px;width: 38px;margin-right: 12px;margin-left: -81px;margin-bottom: 17px;"><span>Lec</span></div>
                </a> 
				
                <hr class="sidebar-divider my-0">
                <ul class="nav navbar-nav text-light" id="accordionSidebar">
                    <li class="nav-item" role="presentation"><a class="nav-link active" href="index.php"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="AddReult.php"><i class="fas fa-list-ul"></i><span>Add results</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="openresult.php"><i class="fas fa-table"></i><span>Open all results</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="SubjectEnrolling.php"><i class="fas fa-file-alt"></i><span>Subject Enrolling</span></a></li>
                   <a class="nav-link" href="Lecturerchangepassword.php"><i class="fas fa-key"></i>Change Password<span></span></a></li>
                
				
				</ul>
				
                <div class="text-center d-none d-md-inline"><button class="btn rounded-circle border-0" id="sidebarToggle" type="button"></button></div>
            </div>
        </nav>
        <div class="d-flex flex-column" id="content-wrapper" style="background-image: url(&quot;assets/img/IMG_2036.JPG&quot;);background-size: cover;">
            <div id="content" style="background-color: rgba(7,33,3,0.46);">
                <div class="container-fluid">
                    <div class="d-sm-flex justify-content-between align-items-center mb-4"></div>
					<a href="logout.php">
                    
                    <i class="fa fa-power-off" style="margin-left: 1050px;margin-right: -51px;font-size: 18px;color:white;"></i>
                  
                </a>
                    <h1 style="font-size: 30px;color: rgb(255,255,255);"><strong>Lecturer Dashboard</strong></h1>
									

                    <div class="row">
                        <div class="col-md-6 col-xl-3 mb-4">
                            <a href="registeredstudent.php">
                                <div class="card shadow border-left-primary py-2">
                                    <div class="card-body">
                                        <div class="row align-items-center no-gutters">
                                            <div class="col mr-2">
                                                <div class="text-uppercase text-primary font-weight-bold text-xs mb-1"><span>RegisTered Students</span></div>
                                                <div class="text-dark font-weight-bold h5 mb-0"><span><?php echo htmlentities($count);?></span></div>
                                            </div>
                                            <div class="col-auto"><i class="fas fa-user-graduate fa-2x text-gray-300" style="font-size: 36px;color: rgb(21,52,208);filter: blur(0px) brightness(29%) contrast(103%) grayscale(0%) saturate(109%);"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-6 col-xl-3 mb-4">
                            <a href="subjectlisted.php">
                                <div class="card shadow border-left-success py-2">
                                    <div class="card-body">
                                        <div class="row align-items-center no-gutters">
                                            <div class="col mr-2">
                                                <div class="text-uppercase text-primary font-weight-bold text-xs mb-1"><span>Subject listed</span></div>
                                                <div class="text-dark font-weight-bold h5 mb-0"><span><?php echo htmlentities($countone);?></span></div>
                                            </div>
                                            <div class="col-auto"><i class="fas fa-sort-amount-down fa-2x text-gray-300" style="filter: brightness(38%);"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-6 col-xl-3 mb-4">
                            <a href="EnrolledSubjects.php">
                                <div class="card shadow border-left-warning py-2">
                                    <div class="card-body">
                                        <div class="row align-items-center no-gutters">
                                            <div class="col mr-2">
                                                <div class="text-uppercase text-primary font-weight-bold text-xs mb-1"><span>Enrolled subjects</span></div>
                                                <div class="text-dark font-weight-bold h5 mb-0"><span></span></div>
                                            </div>
                                            <div class="col-auto"><i class="fas fa-list-alt fa-2x text-gray-300" style="filter: brightness(47%);"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-6 col-xl-3 mb-4">
                            <a href="recorrection.php">
                                <div class="card shadow border-left-warning py-2">
                                    <div class="card-body">
                                        <div class="row align-items-center no-gutters">
                                            <div class="col mr-2">
                                                <div class="text-uppercase text-primary font-weight-bold text-xs mb-1"><span >recorrection count</span></div>
                                                <div class="text-dark font-weight-bold h5 mb-0"><span></span></div>
                                            </div>
                                            <div class="col-auto"><i class="fas fa-retweet fa-2x text-gray-300" style="filter: brightness(47%);margin-right: -16px;"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-7 col-xl-8">
                            <div class="card shadow mb-4" style="background-color: rgba(0,0,0,0.3);">
                                <div class="card-header d-flex justify-content-between align-items-center">
                                    <h6 class="text-primary font-weight-bold m-0">Yearly Student Progress</h6>
                                </div>
                                <div class="card-body">
                                    <p style="font-size: 10px;color: rgb(255,255,255);">Average GPA</p>
                                    <div class="chart-area"><canvas data-bs-chart="{&quot;type&quot;:&quot;line&quot;,&quot;data&quot;:{&quot;labels&quot;:[&quot;Begining&quot;,&quot;2015/2016&quot;,&quot;2016/2017&quot;,&quot;2017/2018&quot;,&quot;2018/2019&quot;,&quot;2019/2020&quot;],&quot;datasets&quot;:[{&quot;label&quot;:&quot;Average GPA&quot;,&quot;fill&quot;:true,&quot;data&quot;:[&quot;0&quot;,&quot;2.15&quot;,&quot;2.12&quot;,&quot;2.56&quot;],&quot;backgroundColor&quot;:&quot;rgba(78, 115, 223, 0.05)&quot;,&quot;borderColor&quot;:&quot;rgba(78, 115, 223, 1)&quot;}]},&quot;options&quot;:{&quot;maintainAspectRatio&quot;:false,&quot;legend&quot;:{&quot;display&quot;:false},&quot;title&quot;:{&quot;display&quot;:false},&quot;scales&quot;:{&quot;xAxes&quot;:[{&quot;gridLines&quot;:{&quot;color&quot;:&quot;rgba(255,255,255,0.38)&quot;,&quot;zeroLineColor&quot;:&quot;rgba(255,255,255,0.38)&quot;,&quot;drawBorder&quot;:false,&quot;drawTicks&quot;:false,&quot;borderDash&quot;:[&quot;2&quot;],&quot;zeroLineBorderDash&quot;:[&quot;2&quot;],&quot;drawOnChartArea&quot;:false},&quot;ticks&quot;:{&quot;fontColor&quot;:&quot;#eceeff&quot;,&quot;padding&quot;:20}}],&quot;yAxes&quot;:[{&quot;gridLines&quot;:{&quot;color&quot;:&quot;rgba(255,255,255,0.38)&quot;,&quot;zeroLineColor&quot;:&quot;rgba(255,255,255,0.38)&quot;,&quot;drawBorder&quot;:false,&quot;drawTicks&quot;:false,&quot;borderDash&quot;:[&quot;2&quot;],&quot;zeroLineBorderDash&quot;:[&quot;2&quot;],&quot;drawOnChartArea&quot;:true},&quot;ticks&quot;:{&quot;fontColor&quot;:&quot;#eceeff&quot;,&quot;padding&quot;:20}}]}}}"></canvas></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-5 col-xl-4">
                            <div class="card shadow mb-4" style="background-color: rgba(255,255,255,0);">
                                <div class="card-header d-flex justify-content-between align-items-center">
                                    <h6 class="text-primary font-weight-bold m-0">Student feadback</h6>
                                </div>
                                <div class="card-body">
                                    <div class="chart-area"><canvas data-bs-chart="{&quot;type&quot;:&quot;doughnut&quot;,&quot;data&quot;:{&quot;labels&quot;:[&quot;Helpfull&quot;,&quot;good&quot;,&quot;have some issues&quot;],&quot;datasets&quot;:[{&quot;label&quot;:&quot;&quot;,&quot;backgroundColor&quot;:[&quot;rgba(0,65,254,0.64)&quot;,&quot;rgba(0,241,154,0.64)&quot;,&quot;rgba(0,223,255,0.69)&quot;],&quot;borderColor&quot;:[&quot;#ffffff&quot;,&quot;#ffffff&quot;,&quot;#ffffff&quot;],&quot;data&quot;:[&quot;50&quot;,&quot;30&quot;,&quot;15&quot;]}]},&quot;options&quot;:{&quot;maintainAspectRatio&quot;:false,&quot;legend&quot;:{&quot;display&quot;:false},&quot;title&quot;:{}}}"></canvas></div>
                                    <div
                                        class="text-center small mt-4"><span class="mr-2" style="color: rgb(255,255,255);"><i class="fas fa-circle text-primary"></i>&nbsp;Helpfull</span><span class="mr-2" style="color: rgb(255,255,255);"><i class="fas fa-circle text-success"></i>&nbsp;good</span>
                                        <span
                                            class="mr-2" style="color: rgb(255,255,255);"><i class="fas fa-circle text-info"></i>&nbsp;have some issues</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <footer class="sticky-footer" style="background-color: #042529;">
            <div class="container my-auto">
                <div class="text-center my-auto copyright"><span>Copyright © Rajarata university 2020</span></div>
            </div>
        </footer>
    </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/chart.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
    <script src="assets/js/script.min.js"></script>
</body>

</html>