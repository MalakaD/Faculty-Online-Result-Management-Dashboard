<?php


class csv extends mysqli
{
    private $state_csv=false;
    public function __construct()
	{
	   parent::__construct("localhost","root","","fotresult");
	   if($this-> connect_error) {
	    echo "fail to connect to Database : " .$this->connect_error;
		}
		
	}
	public function import($file)
	{
	//$first=false;
	//$this->state_csv=false;
	$file = fopen($file,'r');
	
	while($row=fgetcsv($file) ){
	//if(!$first){
	//$first=true;}
	//else{
	$value= "'".implode("','",$row)."'";
	$q="INSERT INTO result(RegNumber,Marks,Year,Sem,RegYear, Department, Scode,Publish,Recorrection,SubjectCredit) VALUES(".$value.")";
	//$sql="INSERT INTO  result(Year,Sem,RegYear, Department, Scode) VALUES(:year,:sem,:RegYear,:Department,:subjectcode)";
	//$q="INSERT INTO file(id, first, last, age) VALUES(".$value.")";
	if ($this->query($q) ) {
	$this-> state_csv = true;
	}
	else{
	    $this->state_csv= false;
		echo $this->error;
		}
	
/*$query = $dbh->prepare($sql);
$query->bindParam(':subjectcode',$subjectcode,PDO::PARAM_STR);
$query->bindParam(':Department',$Department,PDO::PARAM_STR);
$query->bindParam(':year',$year,PDO::PARAM_STR);
$query->bindParam(':sem',$sem,PDO::PARAM_STR);
$query->bindParam(':RegYear',$RegYear,PDO::PARAM_STR);

$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
echo "<script>alert('result Added Succesfully');</script>";
}
else 
{
$error="Something went wrong. Please try again";
} */
	
	
	
	
	}
	
	
}
}

?>	