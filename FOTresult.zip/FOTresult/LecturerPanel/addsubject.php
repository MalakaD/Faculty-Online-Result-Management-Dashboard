<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Table - Brand</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
</head>

<body id="page-top">
    <div id="wrapper">
        <nav class="navbar navbar-dark bg-info align-items-start sidebar sidebar-dark accordion bg-gradient-primary p-0" style="background-color: rgb(45,121,164);height: 895px;">
            <div class="container-fluid d-flex flex-column p-0">
                <a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="#">
                    <div class="sidebar-brand-icon rotate-n-15"></div>
                    <div class="sidebar-brand-text mx-3"><img src="assets/img/150px-Rajarata_logo.png" style="font-size: 13px;width: 38px;margin-right: 12px;margin-left: -81px;margin-bottom: 17px;"><span>Lec</span><i class="fa fa-power-off" style="margin-left: 36px;margin-right: -51px;font-size: 18px;"></i></div>
                </a>
                <hr class="sidebar-divider my-0">
                <ul class="nav navbar-nav text-light" id="accordionSidebar">
                    <li class="nav-item" role="presentation"><a class="nav-link" href="index.php"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="AddReult.php"><i class="fas fa-list-ul"></i><span>Add results</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="openresult.php"><i class="fas fa-table"></i><span>Open all results</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="SubjectEnrolling.php"><i class="fas fa-file-alt"></i><span>Subject Enrolling</span></a></li>
                   <a class="nav-link" href="Lecturerchangepassword.php"><i class="fas fa-key"></i>Change Password<span></span></a></li>
                </ul>
                <div class="text-center d-none d-md-inline"><button class="btn rounded-circle border-0" id="sidebarToggle" type="button"></button></div>
            </div>
        </nav>
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content" style="background-image: url(&quot;assets/img/IMG_2036.JPG&quot;);background-size: cover;">
                <div style="background-color: rgba(5,64,60,0.88);height: 61px;">
                    <h1 style="font-size: 28px;padding-top: 9px;color: rgb(255,255,255);">&nbsp;Add Subjects</h1>
                </div>
                <div style="background-color: rgba(22,10,69,0.62);height: 759px;">
                    <form style="height: 527px;"><label style="margin-top: 21px;padding-left: 454;margin-left: 260px;color: rgb(255,255,255);">Select Year&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; :</label><select class="form-control" style="width: 218px;margin-left: 434px;margin-bottom: 11px;margin-top: -32px;height: 38px;"
                            name="year"><optgroup label="Year"><option value="12" selected="">First year</option><option value="13">Second year</option><option value="14">Third year</option><option value="15">Fourth year</option></optgroup></select>
                        <label
                            style="margin-left: 260px;color: rgb(255,255,255);">Select Semester&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; :</label><select class="form-control" style="width: 218px;margin-left: 434px;margin-bottom: 10px;margin-top: -33px;" name="sem"><optgroup label="Semester"><option value="12" selected="">1/1</option><option value="13">1/2</option><option value="14">2/1</option><option value="15">2/2</option><option value="16">3/1</option><option value="17">3/2</option><option value="18">4/1</option><option value="19">4/2</option></optgroup></select>
                            <label
                                style="margin-left: 260px;margin-top: 0px;padding-top: 2px;color: rgb(255,255,255);">Select registered year :</label><select class="form-control" style="width: 218px;margin-left: 434px;margin-top: -37px;" name="RegYear"><optgroup label="Registered Year"><option value="12" selected="">2016/2017</option><option value="13">2017/2018</option><option value="14">2018/2019</option><option value="15">2019/2020</option></optgroup></select>
                                <label
                                    style="margin-left: 260px;margin-top: 13px;padding-top: 2px;color: rgb(255,255,255);">Select Department&nbsp; &nbsp; &nbsp; :</label><select class="form-control" style="width: 218px;margin-left: 434px;margin-top: -37px;" name="Department"><optgroup label="Departments"><option value="12" selected="">Department of ICT</option><option value="13">Department of ENT</option><option value="14">Department of BST</option><option value="15">Department of  EET</option><option value="16">Department of MTT</option><option value="17">Department of  BPT</option><option value="18">Department of  FDT</option></optgroup></select>
                                    <label
                                        style="margin-left: 260px;margin-top: 12px;padding-top: 2px;color: rgb(255,255,255);">Subject Credit&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;:</label><select class="form-control" style="width: 218px;margin-left: 434px;margin-top: -37px;" name="credit"><optgroup label="Subject Credit"><option value="12" selected="">0</option><option value="13">1</option><option value="14">2</option><option value="15">3</option><option value="16">4</option></optgroup></select>
                                        <label
                                            style="margin-left: 260px;margin-top: 12px;padding-top: 2px;color: rgb(255,255,255);">Subject Status&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;:</label><select class="form-control" style="width: 218px;margin-left: 434px;margin-top: -37px;" name="SubStatus"><optgroup label="Subject Status"><option value="12" selected="">Optional</option><option value="13">Compulsery</option></optgroup></select>
                                            <label
                                                style="margin-left: 260px;margin-top: 12px;padding-top: 2px;color: rgb(255,255,255);">Enter subject name&nbsp; &nbsp; &nbsp;:</label><input class="form-control" type="text" style="width: 326px;margin-left: 434px;margin-top: -36px;background-color: rgba(255,255,255,0);color: rgb(255,255,255);"
                                                    name="SubName"><label style="margin-left: 260px;margin-top: 12px;padding-top: 2px;color: rgb(255,255,255);">Enter Subject Code&nbsp; &nbsp; &nbsp;:</label><input class="form-control" type="text" style="width: 326px;margin-left: 434px;margin-top: -36px;background-color: rgba(255,255,255,0);color: rgb(255,255,255);"
                                                    name="SubCode"><button class="btn btn-primary" type="submit" style="background-color: rgba(22,213,178,0.91);margin-left: 434px;margin-top: 24px;">Add Subject</button></form>
                </div>
            </div>
            <footer class="sticky-footer" style="background-color: #042529;">
                <div class="container my-auto">
                    <div class="text-center my-auto copyright"><span>Copyright © Rajarata university 2020</span></div>
                </div>
            </footer>
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/chart.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
    <script src="assets/js/script.min.js"></script>
</body>

</html>