<?php
session_start();
error_reporting(0);
include('config.php');
?>



<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>admindashboard</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
</head>

<body>
    <div id="wrapper">
        <nav class="navbar navbar-dark bg-info align-items-start sidebar sidebar-dark accordion bg-gradient-primary p-0" style="background-color: rgb(45,121,164);height: 895px;">
            <div class="container-fluid d-flex flex-column p-0">
                <a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="#">
                    <div class="sidebar-brand-icon rotate-n-15"></div>
                    <div class="sidebar-brand-text mx-3"><img src="assets/img/150px-Rajarata_logo.png" style="font-size: 13px;width: 38px;margin-right: 12px;margin-left: -81px;margin-bottom: 17px;"><span>Lec</span><i class="fa fa-power-off" style="margin-left: 36px;margin-right: -51px;font-size: 18px;"></i></div>
                </a>
                <hr class="sidebar-divider my-0">
                <ul class="nav navbar-nav text-light" id="accordionSidebar">
                    <li class="nav-item" role="presentation"><a class="nav-link" href="index.php"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="AddReult.php"><i class="fas fa-list-ul"></i><span>Add results</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="openresult.php"><i class="fas fa-table"></i><span>Open all results</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="SubjectEnrolling.php"><i class="fas fa-file-alt"></i><span>Subject Enrolling</span></a></li>
                   <a class="nav-link" href="Lecturerchangepassword.php"><i class="fas fa-key"></i>Change Password<span></span></a></li>
                </ul>
                <div class="text-center d-none d-md-inline"><button class="btn rounded-circle border-0" id="sidebarToggle" type="button"></button></div>
            </div>
        </nav>
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content" style="background-color: rgba(26,197,125,0.87);background-image: url(&quot;assets/img/IMG_2036.JPG&quot;);background-size: cover;">
                <div style="background-color: rgba(2,74,69,0.48);">
                    <h1 style="font-size: 28px;color: rgb(255,250,250);margin-top: 17px;margin-left: 11px;">Subject Listed</h1>
                    <div class="container-fluid" style="height: 745px;background-color: rgba(5,20,48,0.74);margin-top: 25px;">
                        <div class="row">
                            <div class="col-6">
                                <form  method="post" style="height: 435px;width: 790px;margin-left: -244px;margin-top: 4px;"><label style="margin-top: 21px;padding-left: 454;margin-left: 260px;color: rgb(255,255,255);">Select Year&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; :</label><select class="form-control" style="width: 218px;margin-left: 434px;margin-bottom: 11px;margin-top: -32px;height: 38px;"
                                        name="Year"><optgroup label="Year"><option value="First year" selected="">First year</option><option value="Second year">Second year</option><option value="Third year">Third year</option><option value="Fourth year">Fourth year</option></optgroup></select>
                                    <label
                                        style="margin-left: 260px;color: rgb(255,255,255);">Select Semester&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; :</label><select class="form-control" style="width: 218px;margin-left: 434px;margin-bottom: 10px;margin-top: -33px;" name="Sem"><optgroup label="Semester"><option value="1/1" selected="">1/1</option><option value="1/2">1/2</option><option value="2/1">2/1</option><option value="2/2">2/2</option><option value="3/1">3/1</option><option value="3/2">3/2</option><option value="4/1">4/1</option><option value="4/2">4/2</option></optgroup></select>
                                        <label
                                            style="margin-left: 260px;margin-top: 0px;padding-top: 2px;color: rgb(255,255,255);">Select registered year :</label><select class="form-control" style="width: 218px;margin-left: 434px;margin-top: -37px;" name="RegYear"><optgroup label="Registered Year"><option value="2015/2016" selected="">2015/2016</option><option value="2016/2017" selected="">2016/2017</option><option value="2017/2018">2017/2018</option><option value="2018/2019">2018/2019</option><option value="2019/2020">2019/2020</option></optgroup></select>
                                            <label
                                                style="margin-left: 260px;margin-top: 13px;padding-top: 2px;color: rgb(255,255,255);">Select Department&nbsp; &nbsp; &nbsp; :</label><select class="form-control" style="width: 218px;margin-left: 434px;margin-top: -37px;" name="Department"><optgroup label="Departments"><option value="ICT" selected="">Department of ICT</option><option value="ENT">Department of ENT</option><option value=" BST">Department of BST</option><option value="EET">Department of  EET</option><option value="MTT">Department of MTT</option><option value="BPT">Department of  BPT</option><option value="FDT">Department of  FDT</option></optgroup></select>
                                                <button
                                                    class="btn btn-primary" type="submit" style="background-color: rgba(22,213,178,0.91);margin-left: 434px;margin-top: 24px;">&nbsp; &nbsp;Open&nbsp; &nbsp;</button>
                                </form>
                            </div>
                            <div class="col-6">
                                <div class="card shadow" style="width: 629px;margin-top: 22px;padding-top: 0px;margin-left: -99px;background-color: rgba(255,255,255,0);">
                                    <div class="card-header py-3" style="margin-top: -3px;background-color: rgba(2,53,64,0.82);">
                                        <p class="lead text-primary m-0 font-weight-bold" style="filter: brightness(200%);">Subject Name</p>
                                    </div>
                                    <div class="table-responsive" style="height: 359px;">
                                        <table class="table table-hover table-sm">
                                            <thead style="color: rgb(255,255,255);">
                                                <tr>
                                                    <th>Subject Name</th>
                                                    <th>Subject ID</th>
                                                    <th>Credit</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody style="color: rgb(255,255,255);">
											
												
<?php 


$year=$_POST['Year'];
$sem=$_POST['Sem'];
$regyear=$_POST['RegYear'];
$department=$_POST['Department'];
$_SESSION['year']=$year;
$_SESSION['sem']=$sem;
$_SESSION['regyear']=$regyear;
$_SESSION['department']=$department;
 $qery = "SELECT * from subject where subject.Year=:year and subject.Sem=:sem and subject.RegYear=:regyear and subject.Department=:department ";



$stmt = $dbh->prepare($qery);
$stmt->bindParam(':year',$year,PDO::PARAM_STR);
$stmt->bindParam(':sem',$sem,PDO::PARAM_STR);
$stmt->bindParam(':regyear',$regyear,PDO::PARAM_STR);
$stmt->bindParam(':department',$department,PDO::PARAM_STR);
$stmt->execute();
$resultss=$stmt->fetchAll(PDO::FETCH_OBJ);
$cnt=1;


if($stmt->rowCount() > 0)
{
foreach($resultss as $result)
{   ?>
<tr>

                                                            <td><?php echo htmlentities($result->Sname);?></td>
                                                            <td><?php echo htmlentities($result->Scode);?></td>
                                                            <td><?php echo htmlentities($result->Scredit);?></td>
                                                            <td><?php echo htmlentities($result->SubStatus);?></td>

                                                                

</tr>
<?php $cnt=$cnt+1;}} ?>										
											
											
											
											
											</tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <footer class="sticky-footer" style="background-color: #042529;">
                <div class="container my-auto">
                    <div class="text-center my-auto copyright"><span>Copyright © Rajarata university 2020</span></div>
                </div>
            </footer>
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/chart.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
    <script src="assets/js/script.min.js"></script>
</body>

</html>