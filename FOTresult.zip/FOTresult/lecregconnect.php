<?php


$lecudentname=$_POST['Name'];
$lecId=$_POST['LecId']; 
$lecemail=$_POST['email']; 
$lecPassword=$_POST['password']; 
$lecconfirmPassword=$_POST['password-repeat']; 
$lecGender=$_POST['gender']; 
$lecDepartment=$_POST['Department']; 
$Acces="NO";

	// Database connection
	$conn = new mysqli('localhost','root','','fotresult');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
		
	} else {
		$stmt = $conn->prepare("insert into lecturer(LecName,RollId,LecEmail, Gender, Password, Department,LoginAcces) values(?, ?, ?, ?, ?, ?,?)");
		$stmt->bind_param("sssssss", $lecudentname,$lecId, $lecemail, $lecGender, $lecPassword, $lecDepartment,$Acces);
		$execval = $stmt->execute();
		echo $execval;
		echo "<script>alert('Registration Succesfully');document.location = 'lecturerlogin.php';</script>";
		
		$stmt->close();
		$conn->close();
		
	}
	
?>