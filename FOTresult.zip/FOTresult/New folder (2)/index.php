<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>FOT Result Dashboard</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/fonts/line-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
</head>

<body style="height: 1843px;background-size: cover;">

    <div style="background-image: url(&quot;assets/img/IMG_2036.JPG&quot;);background-size: cover;background-position: center;height: 780px;">
	<div style="height: 810px;background-color: rgba(8,69,88,0.40);width: 1348px;">
        <div class="container" style="margin-top: 2px;height: 636px;background-size: cover;padding-top: 327px;max-width: 1188px;">
            <div class="row">
                <div class="col-4 col-sm-4 col-md-4 col-lg-4 text-center d-flex d-sm-flex d-md-flex d-lg-flex d-xl-flex align-self-sm-center align-self-md-center align-self-lg-center align-self-xl-center">
                    <div class="jumbotron text-center" style="background-color: rgba(0,100,255,0.33);margin-top: -309px;height: 220px;width: 376px;margin-bottom: 85px;padding-right: 11px;padding-top: 33px;color: #ffffff;margin-left: -24px;">
                        <h1>Lecturer Guidlines</h1>
                        <p class="float-left">If You are Lecturer in Rajarata University at&nbsp; the Faculty of Technology , you have to follow the guidlines as below the link</p>
                        <p style="height: 248px;margin-left: -21px;"><a class="btn btn-primary" role="button" style="background-color: rgba(97,255,0,0.62);margin-top: -10px;">Learn more</a></p>
                    </div>
                </div>
                <div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center align-self-center align-self-sm-center align-self-md-center align-self-lg-center align-self-xl-center" style="width: 1189px;padding-bottom: 1px;margin-bottom: 7px;margin-top: -274px;"><img src="assets/img/150px-Rajarata_logo.png" style="width: 115px;margin: 0px;"></div>
                <div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center d-flex">
                    <div class="jumbotron text-center" style="margin-top: -307px;height: 220px;margin-bottom: 31px;padding: 39px;padding-bottom: 76px;background-color: rgba(0,100,255,0.6);padding-top: 49px;color: rgb(255,255,255);width: 408px;margin-right: -34px;">
                        <h1 style="margin-top: -23px;">Student Guidlines</h1>
                        <p style="padding-bottom: 0px;margin-bottom: -14px;margin-top: -22px;"><br>If You are Student in Rajarata University at&nbsp; the Faculty of Technology , you have to follow the guidlines as below the link<br><br></p>
                        <p style="height: -5px;"><a class="btn btn-primary" role="button" style="background-color: rgba(97,255,0,0.62);">Learn more</a></p>
                    </div>
                </div>
            </div>
            <nav class="navbar navbar-light shadow-lg navigation-clean-button" style="padding: 17px;padding-right: 9px;background-color: rgba(5,50,50,0.59);color: #ffffff;font-size: 16px;margin-top: -47px;padding-left: 42px;margin-left: 96px;margin-right: 121px;">
                <div class="container-fluid"><a class="navbar-brand text-sm-center text-md-center text-lg-center text-xl-center shadow-lg justify-content-sm-start align-items-lg-start" style="font-size: 29px;filter: blur(0px) grayscale(0%) saturate(100%);margin-left: -46px;padding-left: 140px;margin-right: 7px;padding-right: -3px;">Faculty of Technology - RESULT DASHBOARD</a>
                    <button
                        data-toggle="collapse" class="navbar-toggler shadow" data-target="#navcol-1" style="padding-left: 13px;margin-left: 0px;background-color: rgba(0,255,194,0.55);color: rgb(255,255,255);padding-right: 12px;margin-right: 9px;"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon" style="margin-left: -2px;"></span></button>
                        <div class="collapse navbar-collapse text-center text-sm-center text-md-center text-lg-center text-xl-center"
                            id="navcol-1" style="margin-top: 1px;">
                            <ul class="nav navbar-nav mr-auto">
                                <li class="nav-item" role="presentation"><a class="nav-link active" href="#" style="color: rgb(255,255,255);"><strong>Home</strong></a></li>
                                <li class="nav-item" role="presentation" style="color: rgb(255,255,255);"><a class="nav-link" href="#" style="color: rgb(255,255,255);"><strong>About</strong></a></li>
                                <li class="nav-item" role="presentation"><a class="nav-link" href="#" style="color: rgb(255,255,255);"><strong>Student progress</strong></a></li>
                                <li class="nav-item dropdown"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="#" style="color: rgb(255,255,255);"><strong>Departments</strong></a>
                                    <div class="dropdown-menu" role="menu"><a class="dropdown-item" role="presentation" href="#"><strong>ICT</strong></a><a class="dropdown-item" role="presentation" href="#"><strong>ENT</strong></a><a class="dropdown-item" role="presentation" href="#"><strong>BST</strong></a></div>
                                </li>
                            </ul><span class="navbar-text actions"> <a class="btn btn-light action-button" role="button" href="Register.php" style="background-color: rgb(0,255,255);"><strong>Sign Up</strong></a></span></div>
                </div>
            </nav>
            <div class="row" style="margin-top: 21px;opacity: 1;background-color: rgba(3,50,57,0.52);margin-left: 94px;margin-right: 117px;">
                <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center text-sm-center text-md-center text-lg-center text-xl-center"><a href="lecturerlogin.php" target="_parent"><i class="fas fa-user-tie shadow-lg" style="font-size: 64px;color: rgb(0,255,224);padding-left: 0;filter: brightness(200%) contrast(200%) grayscale(0%) sepia(0%);"></i></a>
                    <p style="color: rgb(255,255,255);font-size: 18px;background-color: rgba(16,61,94,0.69);width: 131px;margin-top: 4px;margin-left: 82px;"><strong>Lecturer Login</strong></p>
                </div>
                <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center text-sm-center text-md-center text-lg-center text-xl-center" style="padding-left: 0px;"><a href="adminlogin.php"><i class="fas fa-user-shield shadow-lg" style="font-size: 64px;color: rgb(0,255,224);padding-left: 0;filter: blur(0px) brightness(200%) contrast(200%) grayscale(0%) hue-rotate(0deg) saturate(103%) sepia(0%);opacity: 1;margin-right: -54px;"></i></a>
                    <p
                        style="color: rgb(255,255,255);font-size: 18px;background-color: rgba(16,61,86,0.73);width: 123px;padding-left: 0px;margin-left: 112px;margin-top: 3px;"><strong>Admin Login</strong></p>
                </div>
                <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center text-sm-center text-md-center text-lg-center text-xl-center"><a href="Studentlogin.php"><i class="fas fa-user-graduate shadow-lg" style="font-size: 64px;color: rgb(0,255,224);padding-left: 0;filter: brightness(200%) contrast(200%) grayscale(0%) sepia(0%);"></i></a>
                    <p style="color: rgb(255,255,255);font-size: 18px;background-color: rgba(16,61,94,0.69);width: 131px;margin-top: 4px;margin-left: 79px;"><strong>Student Login</strong></p>
                </div>
            </div>
        </div>
	  </div>
    </div>
    <div style="height: 802px;margin-left: 0px;width: 1345px;margin-right: 0px;padding-right: 0px;background-size: cover;background-image: url(&quot;assets/img/LUJMedical02.jpg&quot;);">
        <div style="height: 810px;background-color: rgba(8,69,88,0.64);width: 1348px;">
            <div style="background-color: rgba(4,50,84,0.88);height: 63px;filter: blur(0px) brightness(100%);">
                <div class="row">
                    <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center text-sm-center text-md-center text-lg-center text-xl-center" style="font-size: 16px;"><i class="fa fa-facebook-square" style="color: rgb(255,255,255);font-size: 25px;margin-top: 12px;margin-left: 36px;background-size: auto;"></i><i class="fa fa-twitter-square" style="color: rgb(255,255,255);font-size: 25px;margin-top: 12px;margin-left: 49px;background-size: auto;"></i>
                        <i
                            class="fa fa-linkedin-square" style="color: rgb(255,255,255);font-size: 25px;margin-top: 12px;margin-left: 49px;background-size: auto;"></i><i class="la la-university" style="color: rgb(255,255,255);font-size: 25px;margin-top: 12px;margin-left: 49px;background-size: auto;"></i></div>
                    <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center text-sm-center text-md-center text-lg-center text-xl-center">
                        <p class="text-center text-sm-center text-md-center text-lg-center text-xl-center" style="margin-left: 99px;color: rgba(255,255,255,0.67);width: 285px;margin-top: 14px;font-size: 18px;">Rajarata&nbsp; &nbsp; University&nbsp; &nbsp; of&nbsp; &nbsp; SriLanka</p>
                    </div>
                    <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center text-sm-center text-md-center text-lg-center text-xl-center"><i class="fa fa-comments" style="color: rgb(255,255,255);font-size: 25px;margin-top: 12px;margin-left: 49px;background-size: auto;"></i><i class="fa fa-phone-square" style="color: rgb(255,255,255);font-size: 25px;margin-top: 12px;margin-left: 49px;background-size: auto;"></i>
                        <i
                            class="fas fa-chart-pie" style="color: rgb(255,255,255);font-size: 25px;margin-top: 12px;margin-left: 49px;background-size: auto;"></i><i class="fas fa-building" style="color: rgb(255,255,255);font-size: 25px;margin-top: 12px;margin-left: 49px;background-size: auto;"></i></div>
                </div>
                <div class="row">
                    <div class="col-3 col-sm-3 col-md-3 col-lg-3 col-xl-3 text-center text-sm-center text-md-center text-lg-center text-xl-center"><a href="#"><i class="fa fa-list-alt" style="font-size: 94px;color: rgb(255,255,255);margin-top: 157px;"></i><p style="color: rgb(255,255,255);">Exam Timetable</p></a></div>
                    <div class="col-3 col-sm-3 col-md-3 col-lg-3 col-xl-3 text-center text-sm-center text-md-center text-lg-center text-xl-center"><a href="#"><i class="fas fa-tasks" style="font-size: 94px;color: rgb(255,255,255);margin-top: 157px;"></i><p style="color: rgb(255,255,255);">Subjects</p></a></div>
                    <div class="col-3 col-sm-3 col-md-3 col-lg-3 col-xl-3 text-center text-sm-center text-md-center text-lg-center text-xl-center"><a href="#"><i class="fa fa-calculator" style="font-size: 94px;color: rgb(255,255,255);margin-top: 157px;"></i><p style="color: rgb(255,255,255);">GPA Calculator</p></a></div>
                    <div class="col-3 col-sm-3 col-md-3 col-lg-3 col-xl-3 text-center text-sm-center text-md-center text-lg-center text-xl-center"><a href="#"><i class="fa fa-retweet" style="font-size: 94px;color: rgb(255,255,255);margin-top: 157px;"></i><p style="color: rgb(255,255,255);">Re Correction</p></a></div>
                </div>
            </div>
            <div style="height: 84px;margin-top: 346px;">
                <div class="container">
                    <h1 class="text-center text-sm-center text-md-center text-lg-center text-xl-center" style="color: rgb(255,255,255);font-size: 34px;"><strong>Summary Of The System</strong></h1>
                    <p class="text-center text-sm-center text-md-center text-lg-center text-xl-center" style="color: rgb(255,255,255);font-size: 19px;line-height: 42px;letter-spacing: 1px;width: 1022px;margin-top: 45px;margin-left: 33px;">This is the<strong> Result Dashboard </strong>smart platform of Faculty Of Technology<span style="text-decoration: underline;"> </span><strong><span style="text-decoration: underline;">Rajarata University Of SriLanka</span></strong><em>.</em>&nbsp;
                        We put here many features for you. Welcome to new genaration of the <strong>Result Dashboard </strong>and you can learn more about this system by using <em>ABOUT&nbsp; section.&nbsp; Only Lecturers and Students of the Faculty of Technology who own the University e-mail accounts can use this system and are able included in it.</em></p>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-dark" style="background-color: rgb(40,45,50);">
        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-3 item">
                        <h3>Home</h3>
                        <ul>
                            <li><a href="#">Exam Timetable</a></li>
                            <li><a href="#">Subject</a></li>
                            <li><a href="#">GPA Calculator</a></li>
                            <li><a href="#">Re-Correction</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item">
                        <h3>About</h3>
                        <ul>
                            <li><a href="#">Using guidlines</a></li>
                            <li><a href="#">About Features</a></li>
                            <li><a href="#">Security Guidlines</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item">
                        <h3>Logins</h3>
                        <ul>
                            <li><a href="#">Lecturer Logins</a></li>
                            <li><a href="#">Student Logins</a></li>
                            <li><a href="#">Administrator Login</a></li>
                        </ul>
                    </div>
                    <div class="col item social"><a href="#"><i class="icon ion-social-facebook"></i></a><a href="#"><i class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-youtube"></i></a><a href="#"><i class="icon ion-social-linkedin-outline"></i></a>
                        <a
                            href="#" style="margin-top: 24px;"><i class="fas fa-university"></i></a><a href="#"><i class="icon ion-email"></i></a><a href="#"><i class="icon ion-ios-chatbubble-outline"></i></a><a href="#"><i class="fas fa-phone-square"></i></a></div>
                </div>
                <p class="copyright">Rajarata University of Srilanka © 2020</p>
            </div>
        </footer>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>