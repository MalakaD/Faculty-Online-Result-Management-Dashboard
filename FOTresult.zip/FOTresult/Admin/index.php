<?php


include('config.php');


$sql ="SELECT COUNT(*) FROM student ";
$sqlone ="SELECT COUNT(*) FROM subject ";
$sqlunpublish ="SELECT COUNT(*) FROM result where result.Publish='No' ";

$query= $dbh -> query($sql);
$queryone= $dbh -> query($sqlone);
$queryunpublish= $dbh -> query($sqlunpublish);

$count = $query->fetchColumn();
$countone = $queryone->fetchColumn();
$countunpublish = $queryunpublish->fetchColumn();





?>







<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Dashboard - Brand</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
</head>

<body id="page-top" style="height: 891px;">
    <div id="wrapper" style="height: 896px;">
        <nav class="navbar navbar-dark bg-info align-items-start sidebar sidebar-dark accordion bg-gradient-primary p-0" style="background-color: rgb(45,121,164);height: 895px;">
            <div class="container-fluid d-flex flex-column p-0">
                <a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="../index.php">
                    <div class="sidebar-brand-icon rotate-n-15"></div>
                    <div class="sidebar-brand-text mx-3"><img src="assets/img/150px-Rajarata_logo.png"  style="font-size: 13px;width: 38px;margin-right: 12px;margin-left: -81px;margin-bottom: 17px;"></div>
                  
                </a>
				 <a href="../index.php">
                    
                    <div style="color:White; margin-left:5px;" ><h6 style="margin-right:100px;">Log OUT</h6></div>
                  
                </a>
				
                <hr class="sidebar-divider my-0">
                <ul class="nav navbar-nav text-light" id="accordionSidebar">
                    <li class="nav-item" role="presentation"><a class="nav-link active" href="index.php"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="addsubject.php"><i class="fas fa-table"></i><span>Add Subjects</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="openresult.php"><i class="fas fa-table"></i><span>Open all results</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="recorrection.php"><i class="fas fa-reply-all"></i><span>Recorrection</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="StudentLoginAccess.php"><i class="fas fa-reply-all"></i><span>StudentLoginAccess</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="LecturerLoginAcces.php"><i class="fas fa-reply-all"></i><span>LectureLoginAccess</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="sendmail.php"><i class="fa fa-envelope-o"></i>send email<span></span></a><a class="nav-link" href="Adminchangepassword.php"><i class="fas fa-key"></i>Admin Change Password<span></span></a></li>
                </ul>
                <div class="text-center d-none d-md-inline"><button class="btn rounded-circle border-0" id="sidebarToggle" type="button"></button></div>
            </div>
        </nav>
        <div class="d-flex flex-column" id="content-wrapper" style="background-image: url(&quot;assets/img/IMG_2036.JPG&quot;);background-size: cover;">
            <div id="content" style="background-color: rgba(7,33,3,0.46);">
                <div class="container-fluid">
                    <div class="d-sm-flex justify-content-between align-items-center mb-4"></div>
                    <h1 style="font-size: 30px;color: rgb(255,255,255);"><strong>Admin Dashboard</strong></h1>
                    <div class="row">
                        <div class="col-md-6 col-xl-3 mb-4">
                            <a href="registeredstudent.php">
                                <div class="card shadow border-left-primary py-2">
                                    <div class="card-body">
                                        <div class="row align-items-center no-gutters">
                                            <div class="col mr-2">
                                                <div class="text-uppercase text-primary font-weight-bold text-xs mb-1" style="color:black;"><span>RegisTered Students</span></div>
                                                <div class="text-dark font-weight-bold h5 mb-0"><span><?php echo htmlentities($count);?></span></div>
                                            </div>
                                            <div class="col-auto"><i class="fas fa-user-graduate fa-2x text-gray-300" style="font-size: 36px;color: rgb(21,52,208);filter: blur(0px) brightness(29%) contrast(103%) grayscale(0%) saturate(109%);"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-6 col-xl-3 mb-4">
                            <a href="subjectlisted.php">
                                <div class="card shadow border-left-success py-2">
                                    <div class="card-body">
                                        <div class="row align-items-center no-gutters">
                                            <div class="col mr-2">
                                                <div class="text-uppercase text-primary font-weight-bold text-xs mb-1" style="color:black;"><span>Subject listed</span></div>
                                                <div class="text-dark font-weight-bold h5 mb-0"><span><?php echo htmlentities($countone);?></span></div>
                                            </div>
                                            <div class="col-auto"><i class="fas fa-sort-amount-down fa-2x text-gray-300" style="filter: brightness(38%);"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-6 col-xl-3 mb-4">
                            <a href="unpublishedResults.php">
                                <div class="card shadow border-left-warning py-2">
                                    <div class="card-body">
                                        <div class="row align-items-center no-gutters">
                                            <div class="col mr-2">
                                                <div class="text-uppercase text-primary font-weight-bold text-xs mb-1" style="color:black;"><span>unpublished result</span></div>
                                                <div class="text-dark font-weight-bold h5 mb-0"><span><?php echo htmlentities($countunpublish);?></span></div>
                                            </div>
                                            <div class="col-auto"><i class="fas fa-redo fa-2x text-gray-300" style="filter: brightness(47%);"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-6 col-xl-3 mb-4">
                            <a href="recorrection.php">
                                <div class="card shadow border-left-warning py-2">
                                    <div class="card-body">
                                        <div class="row align-items-center no-gutters">
                                            <div class="col mr-2">
                                                <div class="text-uppercase text-primary font-weight-bold text-xs mb-1" style="color:black;"><span >recorrection count</span></div>
                                                <div class="text-dark font-weight-bold h5 mb-0"><span></span></div>
                                            </div>
                                            <div class="col-auto"><i class="fas fa-retweet fa-2x text-gray-300" style="filter: brightness(47%);margin-right: -16px;"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-7 col-xl-8">
                            <div class="card shadow mb-4" style="background-color: rgba(0,0,0,0.3);">
                                <div class="card-header d-flex justify-content-between align-items-center">
                                    <h6 class="text-primary font-weight-bold m-0">Yearly Student Progress</h6>
                                </div>
                                <div class="card-body">
                                    <p style="font-size: 10px;color: rgb(255,255,255);">Average GPA</p>
                                    <div class="chart-area"><canvas data-bs-chart="{&quot;type&quot;:&quot;line&quot;,&quot;data&quot;:{&quot;labels&quot;:[&quot;2015/2016&quot;,&quot;2016/2017&quot;,&quot;2017/2018&quot;,&quot;2018/2019&quot;,&quot;2019/2020&quot;],&quot;datasets&quot;:[{&quot;label&quot;:&quot;GPA Average &quot;,&quot;fill&quot;:true,&quot;data&quot;:[&quot;1.5&quot;,&quot;2.15&quot;,&quot;3.25&quot;,&quot;3.5&quot;,&quot;3.64&quot;],&quot;backgroundColor&quot;:&quot;rgba(78, 115, 223, 0.05)&quot;,&quot;borderColor&quot;:&quot;rgba(78, 115, 223, 1)&quot;}]},&quot;options&quot;:{&quot;maintainAspectRatio&quot;:false,&quot;legend&quot;:{&quot;display&quot;:false},&quot;title&quot;:{&quot;display&quot;:false},&quot;scales&quot;:{&quot;xAxes&quot;:[{&quot;gridLines&quot;:{&quot;color&quot;:&quot;rgba(255,255,255,0.38)&quot;,&quot;zeroLineColor&quot;:&quot;rgba(255,255,255,0.38)&quot;,&quot;drawBorder&quot;:false,&quot;drawTicks&quot;:false,&quot;borderDash&quot;:[&quot;2&quot;],&quot;zeroLineBorderDash&quot;:[&quot;2&quot;],&quot;drawOnChartArea&quot;:false},&quot;ticks&quot;:{&quot;fontColor&quot;:&quot;#eceeff&quot;,&quot;padding&quot;:20}}],&quot;yAxes&quot;:[{&quot;gridLines&quot;:{&quot;color&quot;:&quot;rgba(255,255,255,0.38)&quot;,&quot;zeroLineColor&quot;:&quot;rgba(255,255,255,0.38)&quot;,&quot;drawBorder&quot;:false,&quot;drawTicks&quot;:false,&quot;borderDash&quot;:[&quot;2&quot;],&quot;zeroLineBorderDash&quot;:[&quot;2&quot;],&quot;drawOnChartArea&quot;:true},&quot;ticks&quot;:{&quot;fontColor&quot;:&quot;#eceeff&quot;,&quot;padding&quot;:20}}]}}}"></canvas></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-5 col-xl-4">
                            <div class="card shadow mb-4" style="background-color: rgba(255,255,255,0);">
                                <div class="card-header d-flex justify-content-between align-items-center">
                                    <h6 class="text-primary font-weight-bold m-0">Student feadback</h6>
                                </div>
                                <div class="card-body">
                                    <div class="chart-area"><canvas data-bs-chart="{&quot;type&quot;:&quot;doughnut&quot;,&quot;data&quot;:{&quot;labels&quot;:[&quot;Helpfull&quot;,&quot;good&quot;,&quot;have some issues&quot;],&quot;datasets&quot;:[{&quot;label&quot;:&quot;&quot;,&quot;backgroundColor&quot;:[&quot;rgba(0,65,254,0.64)&quot;,&quot;rgba(0,241,154,0.64)&quot;,&quot;rgba(0,223,255,0.69)&quot;],&quot;borderColor&quot;:[&quot;#ffffff&quot;,&quot;#ffffff&quot;,&quot;#ffffff&quot;],&quot;data&quot;:[&quot;20&quot;,&quot;30&quot;,&quot;15&quot;]}]},&quot;options&quot;:{&quot;maintainAspectRatio&quot;:false,&quot;legend&quot;:{&quot;display&quot;:false},&quot;title&quot;:{}}}"></canvas></div>
                                    <div
                                        class="text-center small mt-4"><span class="mr-2" style="color: rgb(255,255,255);"><i class="fas fa-circle text-primary"></i>&nbsp;Helpfull</span><span class="mr-2" style="color: rgb(255,255,255);"><i class="fas fa-circle text-success"></i>&nbsp;good</span>
                                        <span
                                            class="mr-2" style="color: rgb(255,255,255);"><i class="fas fa-circle text-info"></i>&nbsp;have some issues</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <footer class="sticky-footer" style="background-color: #042529;">
            <div class="container my-auto">
                <div class="text-center my-auto copyright"><span>Copyright © Rajarata university 2020</span></div>
            </div>
        </footer>
    </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/chart.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
    <script src="assets/js/script.min.js"></script>
</body>

</html>