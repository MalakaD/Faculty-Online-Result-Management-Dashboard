<?php
session_start();
error_reporting(0);
include('config.php');

$Regnumber=($_POST['StRegID']);





$q = "UPDATE student SET student.LoginAcces='Yes' WHERE student.RegNumber=:Regnumber ";

$publish = $dbh->prepare($q);
$publish->bindParam(':Regnumber',$Regnumber,PDO::PARAM_STR);
$publish->execute();


$qery="select * from student where  student.LoginAcces='NO' ";

$stmt = $dbh->prepare($qery);
$stmt->execute();
$resultss=$stmt->fetchAll(PDO::FETCH_OBJ);
$cnt=1;



?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Blank Page - Brand</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
</head>

<body id="page-top">
    <div id="wrapper">
        <nav class="navbar navbar-dark bg-info align-items-start sidebar sidebar-dark accordion bg-gradient-primary p-0" style="background-color: rgb(45,121,164);height: 895px;">
            <div class="container-fluid d-flex flex-column p-0">
                <a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="#">
                    <div class="sidebar-brand-icon rotate-n-15"></div>
                    <div class="sidebar-brand-text mx-3"><img src="assets/img/150px-Rajarata_logo.png" style="font-size: 13px;width: 38px;margin-right: 12px;margin-left: -81px;margin-bottom: 17px;"><span>Admin</span></div>
                </a>
                <hr class="sidebar-divider my-0">
                <ul class="nav navbar-nav text-light" id="accordionSidebar">
                    <li class="nav-item" role="presentation"><a class="nav-link" href="index.php"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="addsubject.php"><i class="fas fa-table"></i><span>Add Subjects</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="openresult.php"><i class="fas fa-table"></i><span>Open all results</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link active" href="recorrection.php"><i class="fas fa-reply-all"></i><span>Recorrection</span></a></li>
					 <li class="nav-item" role="presentation"><a class="nav-link" href="StudentLoginAccess.php"><i class="fas fa-reply-all"></i><span>StudentLoginAccess</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="LecturerLoginAcces.php"><i class="fas fa-reply-all"></i><span>LectureLoginAccess</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="sendmail.php"><i class="fa fa-envelope-o"></i>send email<span></span></a><a class="nav-link" href="Adminchangepassword.php"><i class="fas fa-key"></i>Admin Change Password<span></span></a></li>
                </ul>
                <div class="text-center d-none d-md-inline"><button class="btn rounded-circle border-0" id="sidebarToggle" type="button"></button></div>
            </div>
        </nav>
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content" style="background-color: rgba(26,197,125,0.87);background-image: url(&quot;assets/img/IMG_2036.JPG&quot;);background-size: cover;">
                <div style="background-color: rgba(2,74,69,0.48);">
                    <h1 style="font-size: 28px;color: rgb(255,250,250);margin-top: 17px;margin-left: 11px;">Student Login Access</h1>
                    <div class="container-fluid" style="height: 745px;background-color: rgba(5,20,48,0.74);margin-top: 25px;">
                        <div class="row">
                            <div class="col-6">
                                <form method="post" style="height: 435px;width: 829px;margin-left: -253px;margin-top: 31px;"><label style="margin-left: 260px;margin-top: 12px;padding-top: 2px;color: rgb(255,255,255);">Enter Student Reg ID&nbsp; :</label><input class="form-control" type="text" style="width: 226px;margin-left: 434px;margin-top: -36px;background-color: rgba(255,255,255,0);color: rgb(255,255,255);"
                                        name="StRegID">
                                    
										<button class="btn btn-primary" type="submit" style="background-color: rgba(22,213,178,0.91);margin-left: 434px;margin-top: 24px;">&nbsp; &nbsp;Accept&nbsp; &nbsp;</button></form>
                            </div>
                            <div class="col-6">
                                <div class="card shadow" style="width: 616px;margin-top: 22px;padding-top: 0px;margin-left: -112px;background-color: rgba(255,255,255,0);height: 263px;">
                                    <div class="card-header py-3" style="margin-top: -3px;background-color: rgba(2,53,64,0.82);">
                                        <p class="text-primary m-0 font-weight-bold" style="filter: brightness(200%);">Recorrection count</p>
                                    </div>
                                    <div class="table-responsive" style="height: 131px;">
                                        <table class="table table-hover table-sm">
                                            <thead style="color: rgb(255,255,255);">
                                                <tr>
                                                    <th style="width: 190px;">Student Rgistration ID</th>
                                                    <th style="width: 100px;">RegYear</th>
                                                    <th style="width: 100px;">Student-Email</th>
                                                    
                                                    <th style="width: 68px;">Dept</th>
                                                    
                                                </tr>
                                            </thead>
                                            <tbody style="color: rgb(255,255,255);">
											
		<?php 




if($stmt->rowCount() > 0)
{
foreach($resultss as $result)
{   ?>
<tr>

                                                            <td><?php echo htmlentities($result->RegNumber);?></td>
                                                            <td><?php echo htmlentities($result->RegYear);?></td>
                                                            <td><?php echo htmlentities($result->StEmail);?></td>
                                                            <td><?php echo htmlentities($result->Department);?></td>
                                                           
                                                                

</tr>
<?php $cnt=$cnt+1;}} ?>
																					
											
											
											</tbody>
                                        </table>
                                    </div>
                                </div>
                               
                        </div>
                    </div>
                </div>
            </div>
            <footer class="sticky-footer" style="background-color: #042529;">
                <div class="container my-auto">
                    <div class="text-center my-auto copyright"><span>Copyright � Rajarata university 2020</span></div>
                </div>
            </footer>
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/chart.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
    <script src="assets/js/script.min.js"></script>
</body>

</html>