<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once 'C:\users\malaka\vendor\autoload.php';

$mail = new PHPMailer;

/*$mail->From = "from@yourdomain.com";
$mail->FromName = "Full Name";

$mail->addAddress("k1974.malaka@gmail.com", "Recipient Name");

//Provide file path and name of the attachments
$mail->addAttachment("file.txt", "File.txt");        
$mail->addAttachment("images/profile.png"); //Filename is optional

$mail->isHTML(true);

$mail->Subject = "Subject Text";
$mail->Body = "<i>Mail body in HTML</i>";
$mail->AltBody = "This is the plain text version of the email content";

try {
    $mail->send();
    echo "Message has been sent successfully";
} catch (Exception $e) {
    echo "Mailer Error: " . $mail->ErrorInfo;
} */



//Enable SMTP debugging.
$mail->SMTPDebug = 3;                               
//Set PHPMailer to use SMTP.
$mail->isSMTP();            
//Set SMTP host name                          
$mail->Host = "smtp.gmail.com";
//Set this to true if SMTP host requires authentication to send email
$mail->SMTPAuth = true;                          
//Provide username and password     
$mail->Username = "itt1617007@tec.rjt.ac.lk";                 
$mail->Password = "1qaz2wsx@";                           
//If SMTP requires TLS encryption then set it
$mail->SMTPSecure = "tls";                           
//Set TCP port to connect to
$mail->Port = 587;                                   

$mail->From = "itt1617007@tec.rjt.ac.lk";
$mail->FromName = "FOT Result Dashboard";

$mail->addAddress($_POST['classname'],"student");

$mail->isHTML(true);

$mail->Subject =$_POST['classnamenumeric'];
$mail->Body = $_POST['section'] ;//"<i><h1>hey i am malaka dananjaya bandara .. i have make mail function,, and i won ,, yeah</h1></i>";
$mail->AltBody = "This is the plain text version of the email content";

try {
    $mail->send();
    echo "Message has been sent successfully";
} catch (Exception $e) {
    echo "Mailer Error: " . $mail->ErrorInfo;
}