
<?php
/* session_start();
error_reporting(1);
include('config.php');
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
    }
    else{
if(isset($_POST['submit']))
    {
	
	$username=$_SESSION['alogin'];
	
	
	
	
	$markcountAt ="SELECT COUNT(Marks)
FROM result where result.Marks='A+'";

$markcountAtt ="SELECT COUNT(Marks)
FROM result where result.Marks='A' result.RegNumber=:username ";

$markcountAttt ="SELECT COUNT(Marks)
FROM result where result.Marks='A-' result.RegNumber=:username ";

$markcountBt ="SELECT COUNT(Marks)
FROM result where result.Marks='B+' result.RegNumber=:username ";

$markcountBtt ="SELECT COUNT(Marks)
FROM result where result.Marks='B' result.RegNumber=:username ";

$markcountBttt ="SELECT COUNT(Marks)
FROM result where result.Marks='B-' result.RegNumber=:username ";

$markcountCt ="SELECT COUNT(Marks)
FROM result where result.Marks='C+' result.RegNumber=:username ";

$markcountCtt ="SELECT COUNT(Marks)
FROM result where result.Marks='C' result.RegNumber=:username ";

$markcountCttt ="SELECT COUNT(Marks)
FROM result where result.Marks='C-' result.RegNumber=:username ";

$markcountDt ="SELECT COUNT(Marks)
FROM result where result.Marks='D+' result.RegNumber=:username ";

$markcountDtt ="SELECT COUNT(Marks)
FROM result where result.Marks='D' result.RegNumber=:username ";


$markcountDttt ="SELECT COUNT(Marks)
FROM result where result.Marks='D-' result.RegNumber=:username ";

$markcountE ="SELECT COUNT(Marks)
FROM result where result.Marks='E' result.RegNumber=:username ";




$queryAt= $dbh -> query($markcountAt);
//$queryAt->bindParam(':username',$username,PDO::PARAM_STR);
$queryAtt= $dbh -> query($markcountAtt);
//$queryAtt->bindParam(':username',$username,PDO::PARAM_STR);
$queryAttt= $dbh -> query($markcountAttt);
//$queryAttt->bindParam(':username',$username,PDO::PARAM_STR);
$queryBt= $dbh -> query($markcountBt);
//$queryBt->bindParam(':username',$username,PDO::PARAM_STR);
$queryBtt= $dbh -> query($markcountBtt);
//$queryBtt->bindParam(':username',$username,PDO::PARAM_STR);
$queryBttt= $dbh -> query($markcountBttt);
//$queryBttt->bindParam(':username',$username,PDO::PARAM_STR);
$queryCt= $dbh -> query($markcountCt);
//$queryCt->bindParam(':username',$username,PDO::PARAM_STR);
$queryCtt= $dbh -> query($markcountCtt);
//$queryCtt->bindParam(':username',$username,PDO::PARAM_STR);
$queryCttt= $dbh -> query($markcountCttt);
//$queryCttt->bindParam(':username',$username,PDO::PARAM_STR);
$queryDt= $dbh -> query($markcountDt);
//$queryDt->bindParam(':username',$username,PDO::PARAM_STR);
$queryDtt= $dbh -> query($markcountDtt);
//$queryDtt->bindParam(':username',$username,PDO::PARAM_STR);
$queryDttt= $dbh -> query($markcountDttt);
//$queryDttt->bindParam(':username',$username,PDO::PARAM_STR);
$queryE= $dbh -> query($markcountE);
//$queryE->bindParam(':username',$username,PDO::PARAM_STR);

$countAt = $queryAt->fetchColumn();
$countAtt = $queryAtt->fetchColumn();
$countAttt = $queryAttt->fetchColumn();
$countBt = $queryBt->fetchColumn();
$countBtt = $queryBtt->fetchColumn();
$countBttt = $queryBttt->fetchColumn();
$countCt = $queryCt->fetchColumn();
$countCtt = $queryCtt->fetchColumn();
$countCttt = $queryCttt->fetchColumn();
$countDt = $queryDt->fetchColumn();
$countDtt = $queryDtt->fetchColumn();
$countDttt = $queryDttt->fetchColumn();
$countE = $queryE->fetchColumn();


*/
include('config.php');

	
	$sql ="SELECT COUNT(*) FROM student ";
$sqlone ="SELECT COUNT(*) FROM subject ";
$query= $dbh -> query($sql);
$queryone= $dbh -> query($sqlone);
$count = $query->fetchColumn();
$countone = $queryone->fetchColumn();
	
	
	
	
	
 ?>




<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Dashboard - Brand</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
</head>

<body id="page-top" style="height: 891px;">
    <div id="wrapper" style="height: 896px;">
        <nav class="navbar navbar-dark bg-info align-items-start sidebar sidebar-dark accordion bg-gradient-primary p-0" style="background-color: rgb(45,121,164);height: 895px;">
            <div class="container-fluid d-flex flex-column p-0">
                <a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="#">
                    <div class="sidebar-brand-icon rotate-n-15"></div>
                    <div class="sidebar-brand-text mx-3"><img src="assets/img/150px-Rajarata_logo.png" style="font-size: 13px;width: 38px;margin-right: 12px;margin-left: -81px;margin-bottom: 17px;"><span style="margin-left: 0px;margin-right: -82px;">Student</span></div>
                </a>
                <hr class="sidebar-divider my-0">
                <ul class="nav navbar-nav text-light" id="accordionSidebar">
                    <li class="nav-item" role="presentation"><a class="nav-link active" href="index.php"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="recorrection.php"><i class="fas fa-list-ul"></i><span>Recorrection&nbsp;</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="openresult.php"><i class="fas fa-table"></i><span>Open my results</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="SubjectEnrolling.php"><i class="fas fa-file-alt"></i><span>Subject Enrolling</span></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="Lecturerchangepassword.php"><i class="fas fa-key"></i>Change Password<span></span></a></li>
                </ul>
                <div class="text-center d-none d-md-inline"><button class="btn rounded-circle border-0" id="sidebarToggle" type="button"></button></div>
            </div>
        </nav>
        <div class="d-flex flex-column" id="content-wrapper" style="background-image: url(&quot;assets/img/IMG_2036.JPG&quot;);background-size: cover;">
            <div id="content" style="background-color: rgba(7,33,3,0.46);">
                <div class="container-fluid">
                    <div class="d-sm-flex justify-content-between align-items-center mb-4"></div>
                    <h1 style="font-size: 30px;color: rgb(255,255,255);"><strong>Student Dashboard</strong></h1><a href="../index.php"><i class="fa fa-power-off" style="margin-left: 1068px;margin-right: -51px;font-size: 18px;color: rgb(255,255,255);margin-bottom: 0px;margin-top: 0px;padding-bottom: 15px;padding-top: 0px;"></i></a>
                    <div
                        class="row">
                        <div class="col-md-6 col-xl-3 mb-4">
                            <a href="registeredstudent.php">
                                <div class="card shadow border-left-primary py-2">
                                    <div class="card-body">
                                        <div class="row align-items-center no-gutters">
                                            <div class="col mr-2">
                                                <div class="text-uppercase text-primary font-weight-bold text-xs mb-1"><span>RegisTered Students</span></div>
                                                <div class="text-dark font-weight-bold h5 mb-0"><span><?php echo htmlentities($count);?></span></div>
                                            </div>
                                            <div class="col-auto"><i class="fas fa-user-graduate fa-2x text-gray-300" style="font-size: 36px;color: rgb(21,52,208);filter: blur(0px) brightness(29%) contrast(103%) grayscale(0%) saturate(109%);"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-6 col-xl-3 mb-4">
                            <a href="subjectlisted.php">
                                <div class="card shadow border-left-success py-2">
                                    <div class="card-body">
                                        <div class="row align-items-center no-gutters">
                                            <div class="col mr-2">
                                                <div class="text-uppercase text-primary font-weight-bold text-xs mb-1"><span>Subject listed</span></div>
                                                <div class="text-dark font-weight-bold h5 mb-0"><span><?php echo htmlentities($countone);?></span></div>
                                            </div>
                                            <div class="col-auto"><i class="fas fa-sort-amount-down fa-2x text-gray-300" style="filter: brightness(38%);"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-6 col-xl-3 mb-4">
                            <a href="EnrolledSubjects.php">
                                <div class="card shadow border-left-warning py-2">
                                    <div class="card-body">
                                        <div class="row align-items-center no-gutters">
                                            <div class="col mr-2">
                                                <div class="text-uppercase text-primary font-weight-bold text-xs mb-1"><span>Enrolled subjects</span></div>
                                                <div class="text-dark font-weight-bold h5 mb-0"><span></span></div>
                                            </div>
                                            <div class="col-auto"><i class="fas fa-list-alt fa-2x text-gray-300" style="filter: brightness(47%);"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-6 col-xl-3 mb-4">
                            <a href="lecturers.php">
                                <div class="card shadow border-left-warning py-2">
                                    <div class="card-body">
                                        <div class="row align-items-center no-gutters">
                                            <div class="col mr-2">
                                                <div class="text-uppercase text-primary font-weight-bold text-xs mb-1"><span>Lecturers&nbsp;</span></div>
                                                <div class="text-dark font-weight-bold h5 mb-0"><span></span></div>
                                            </div>
                                            <div class="col-auto"><i class="fas fa-retweet fa-2x text-gray-300" style="filter: brightness(47%);margin-right: -16px;"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                </div>
                <div class="row">
                    <div class="col-lg-7 col-xl-8">
                        <div class="card shadow mb-4" style="background-color: rgba(0,0,0,0.3);">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h6 class="text-primary font-weight-bold m-0">Yearly Student Progress</h6>
                            </div>
                            <div class="card-body">
                                <p style="font-size: 10px;color: rgb(255,255,255);">Average GPA</p>
                                <div class="chart-area"><canvas data-bs-chart="{&quot;type&quot;:&quot;line&quot;,&quot;data&quot;:{&quot;labels&quot;:[&quot;Begining&quot;,&quot;2015/2016&quot;,&quot;2016/2017&quot;,&quot;2017/2018&quot;,&quot;2018/2019&quot;,&quot;2019/2020&quot;],&quot;datasets&quot;:[{&quot;label&quot;:&quot;Total GPA&quot;,&quot;fill&quot;:true,&quot;data&quot;:[&quot;0&quot;,&quot;2.15&quot;,&quot;2.12&quot;,&quot;2.56&quot;],&quot;backgroundColor&quot;:&quot;rgba(78, 115, 223, 0.05)&quot;,&quot;borderColor&quot;:&quot;rgba(78, 115, 223, 1)&quot;}]},&quot;options&quot;:{&quot;maintainAspectRatio&quot;:false,&quot;legend&quot;:{&quot;display&quot;:false},&quot;title&quot;:{&quot;display&quot;:false},&quot;scales&quot;:{&quot;xAxes&quot;:[{&quot;gridLines&quot;:{&quot;color&quot;:&quot;rgba(255,255,255,0.38)&quot;,&quot;zeroLineColor&quot;:&quot;rgba(255,255,255,0.38)&quot;,&quot;drawBorder&quot;:false,&quot;drawTicks&quot;:false,&quot;borderDash&quot;:[&quot;2&quot;],&quot;zeroLineBorderDash&quot;:[&quot;2&quot;],&quot;drawOnChartArea&quot;:false},&quot;ticks&quot;:{&quot;fontColor&quot;:&quot;#eceeff&quot;,&quot;padding&quot;:20}}],&quot;yAxes&quot;:[{&quot;gridLines&quot;:{&quot;color&quot;:&quot;rgba(255,255,255,0.38)&quot;,&quot;zeroLineColor&quot;:&quot;rgba(255,255,255,0.38)&quot;,&quot;drawBorder&quot;:false,&quot;drawTicks&quot;:false,&quot;borderDash&quot;:[&quot;2&quot;],&quot;zeroLineBorderDash&quot;:[&quot;2&quot;],&quot;drawOnChartArea&quot;:true},&quot;ticks&quot;:{&quot;fontColor&quot;:&quot;#eceeff&quot;,&quot;padding&quot;:20}}]}}}"></canvas></div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
					
					<form method="post" action="resultsheetopen.php" >
					<button type="submit" name="submit"  style="margin-top: 20px;background-color: rgba(54,185,204,0.39);" class="btn btn-info btn-icon-split" ><span class="text-white-50 icon"><i class="fas fa-select-circle"></i></span><span class=" text" style="background-color: rgba(0,255,148,0.41);">Open Full result sheet</span></button>
                        </form>
						
						<a
                            class="btn btn-info btn-icon-split" role="button" style="margin-top: 20px;background-color: rgba(54,185,204,0.39);"><span class="text-white-50 icon"><i class="fas fa-info-circle"></i></span><span class="text-white text">Guidline for you&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span></a>
                            <div class="chart-area" style="width: 218px;margin: 0px;margin-top: 20px;margin-left: 21px;margin-right: 0px;background-color: rgba(255,255,255,0);padding: 0px;padding-top: 3px;padding-bottom: 0px;margin-bottom: 0px;"><canvas data-bs-chart="{&quot;type&quot;:&quot;doughnut&quot;,&quot;data&quot;:{&quot;labels&quot;:[&quot;A+&quot;,&quot;A Passes&quot;,&quot;A-&quot;,&quot;B+&quot;,&quot;B Passes&quot;,&quot;B-&quot;,&quot;C+&quot;,&quot;C passes&quot;,&quot;C-&quot;,&quot;D+&quot;,&quot;D&quot;,&quot;D-&quot;,&quot;E&quot;],&quot;datasets&quot;:[{&quot;label&quot;:&quot;&quot;,&quot;backgroundColor&quot;:[&quot;rgba(78,115,223,0.73)&quot;,&quot;rgba(28,200,138,0.76)&quot;,&quot;rgba(54,185,204,0.76)&quot;,&quot;rgba(215,27,27,0.7)&quot;,&quot;rgba(40,7,244,0.56)&quot;,&quot;rgba(182,247,0,0.64)&quot;,&quot;rgba(44,230,107,0.95)&quot;,&quot;rgba(227,186,43,0.71)&quot;,&quot;rgba(132,116,32,0.58)&quot;,&quot;rgba(221,141,20,0.2)&quot;,&quot;rgba(191,8,255,0.8)&quot;,&quot;rgba(255,71,46,0.61)&quot;,&quot;rgba(255,0,199,0.8)&quot;],&quot;borderColor&quot;:[&quot;#ffffff&quot;,&quot;#ffffff&quot;,&quot;#ffffff&quot;,&quot;#ffffff&quot;,&quot;#ffffff&quot;,&quot;#ffffff&quot;,&quot;#ffffff&quot;,&quot;#ffffff&quot;,&quot;#ffffff&quot;,&quot;#ffffff&quot;,&quot;#ffffff&quot;,&quot;#ffffff&quot;,&quot;#ffffff&quot;],&quot;data&quot;:[&quot;8&quot;,&quot;20&quot;,&quot;15&quot;,&quot;45&quot;,&quot;5&quot;,&quot;16&quot;,&quot;10&quot;,&quot;7&quot;,&quot;2&quot;,&quot;23&quot;,&quot;3&quot;,&quot;8&quot;,&quot;3&quot;]}]},&quot;options&quot;:{&quot;maintainAspectRatio&quot;:false,&quot;legend&quot;:{&quot;display&quot;:false},&quot;title&quot;:{&quot;text&quot;:&quot;Your Full result chart&quot;,&quot;display&quot;:true,&quot;fontColor&quot;:&quot;#ffffff&quot;,&quot;fontSize&quot;:&quot;17&quot;}}}"></canvas></div>
                    </div>
                </div>
            </div>
        </div>
        <footer class="sticky-footer" style="background-color: #042529;">
            <div class="container my-auto">
                <div class="text-center my-auto copyright"><span>Copyright © Rajarata university 2020</span></div>
            </div>
        </footer>
    </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/smart-forms.min.js"></script>
    <script src="assets/js/chart.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
    <script src="assets/js/script.min.js"></script>
</body>

</html>