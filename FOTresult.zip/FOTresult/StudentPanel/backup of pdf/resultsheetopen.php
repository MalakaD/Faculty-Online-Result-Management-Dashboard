

<?php
session_start();
error_reporting(1);
include('config.php');
if(strlen($_SESSION['alogin'])=="")
    {   
    header("Location: index.php"); 
    }
    else{
if(isset($_POST['submit']))
    {

//$year=$_POST['year'];
//$sem=$_POST['sem'];
$username=$_SESSION['alogin'];

//$_SESSION['year']=$year;
//$_SESSION['sem']=$sem;



$qery = "SELECT * from result where result.RegNumber=:username and result.Publish='Yes' ";

$stmt = $dbh->prepare($qery);
//$stmt->bindParam(':year',$year,PDO::PARAM_STR);
//$stmt->bindParam(':sem',$sem,PDO::PARAM_STR);
$stmt->bindParam(':username',$username,PDO::PARAM_STR);
$stmt->execute();
$resultss=$stmt->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
$Grade=0;

}} ?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Table - Brand</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
	 <link rel="stylesheet" href="css/bootstrap.min.css" media="screen" >
        <link rel="stylesheet" href="css/font-awesome.min.css" media="screen" >
        <link rel="stylesheet" href="css/animate-css/animate.min.css" media="screen" >
        <link rel="stylesheet" href="css/lobipanel/lobipanel.min.css" media="screen" >
        <link rel="stylesheet" href="css/prism/prism.css" media="screen" >
        <link rel="stylesheet" href="css/main.css" media="screen" >
        <script src="js/modernizr/modernizr.min.js"></script>
</head>

<body >
<section class="section" id="exampl">
    <div style="align:center;">
        
        <div  id="content-wrapper" style="align:center;">
            
                <div >
                    <h1 style="font-size: 28px;color:black;margin-top: 17px; margin-left:auto;text-align:center;">Full Result sheet</h1>
                   
                        <div class="row" >
                          
                               
                            </div>
                            <div class="col-12">
                                    
                                    <div class="" style="height: auto; align:center;">
                                        
                                                <table class="table table-hover table-bordered"  border="1" width="100%" style="height: auto; align:center;>
                                                <thead>
                                                        <tr style="text-align: center">
                                                            <th style="text-align: center">Subject code</th>
                                                            <th style="text-align: center"> Marks</th>    
                                                        </tr>
                                               </thead>
                                            <tbody style="color:black;">
											
<?php 




if($stmt->rowCount() > 0)

?><p style="colour:black;">Registration Number - <?php echo htmlentities($username);?></p>
<?php 
{
foreach($resultss as $result)
{   ?>
<tr>

                                                            <td Style="color:black;text-align: center;"><?php echo htmlentities($result->Scode);?></td>
                                                            <td Style="color:black;text-align: center;" ><?php echo htmlentities($result->Marks);?></td>
                                                           
                                                                

</tr>

<?php $cnt=$cnt+1;}} ?>
<tr>
                              
<td colspan="3" align="center"><i class="fa fa-print fa-2x"  style="cursor:pointer" OnClick="CallPrint()" ></i></td>
                                                             </tr>

																						
											
											
											</tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="col">
   
                              
        </div>
    </div>
    </div>
    </div>
    <footer class="sticky-footer" style="background-color: #042529;">
        <div class="container my-auto">
            <div class="text-center my-auto copyright"><span>Copyright � Rajarata university 2020</span></div>
        </div>
    </footer>
    </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a></div>
    
	

        <script>
       function CallPrint() {
var prtContent = document.getElementById("exampl");
var WinPrint = window.open('', '', 'left=0,top=0,width=800,height=900,toolbar=0,scrollbars=0,status=0');
WinPrint.document.write(prtContent.innerHTML);
WinPrint.document.close();
WinPrint.focus();
WinPrint.print();
WinPrint.close();
}
</script>

        </section>
	
</body>
 

</html>